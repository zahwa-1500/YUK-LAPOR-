package com.example.yuklapor;

import com.google.firebase.auth.FirebaseUser;

public interface RegisterView {
    void onRegisterSuccess(FirebaseUser user);
    void onRegisterFailure(String message);
    void onUploadSuccess();
}
